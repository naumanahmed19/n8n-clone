// Export the node definitions
module.exports = {
  nodes: {
    'count': require('./nodes/count.node.js')
  }
};
