// Export the node definitions
module.exports = {
  nodes: {
    'upercase': require('./nodes/upercase.node.js')
  }
};
