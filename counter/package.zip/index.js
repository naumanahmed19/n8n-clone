// Export the node definitions
module.exports = {
  nodes: {
    counter: require("./nodes/counter.node.js"),
  },
};